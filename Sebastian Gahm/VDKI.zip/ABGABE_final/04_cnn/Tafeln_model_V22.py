import tensorflow as tf
import tensorflow.keras as keras
import matplotlib.pyplot as plt
from PIL import Image
import numpy as np
import os

#_________Variablenzuweisungen______________

batch_size = 15
img_height = 512
img_width = 512
num_classes = 15

train_folder = r"D:\Student\riju1022\riju1022\Bilder_sort\data"
val_folder = r"D:\Student\riju1022\riju1022\Bilder_sort\val"

#________Funktionsdefinitionen_______________

def load_images_to_array(folder_path, name):
    # Liste für Bilddateien und Klassennamen initialisieren
    image_files = []
    class_names = []
    
    # Durchlaufe alle Unterordner und Dateien im angegebenen Ordner
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            # Überprüfe, ob die Datei eine PNG-Datei ist
            if file.endswith('.png'):
                # Füge den vollständigen Pfad zur Bilddatei zur Liste hinzu
                image_files.append(os.path.join(root, file))
                # Extrahiere den Basisnamen des Ordners (Klassenname) und füge ihn zur Liste hinzu
                class_names.append(os.path.basename(root))

            if file.endswith('.jpg'):
                # Füge den vollständigen Pfad zur Bilddatei zur Liste hinzu
                image_files.append(os.path.join(root, file))
                # Extrahiere den Basisnamen des Ordners (Klassenname) und füge ihn zur Liste hinzu
                class_names.append(os.path.basename(root))
    
    # Anzahl der geladenen Bilder
    num_images = len(image_files)
    print(len(image_files))
    print(len(class_names))
    
    # Überprüfe, ob mindestens ein Bild im Ordner gefunden wurde
    if num_images == 0:
        print("Keine Bilder im angegebenen Ordner gefunden.")
        return None
    
    # Erstelle ein leeres NumPy-Array mit der richtigen Form (Anzahl der Bilder, Bildhöhe, Bildbreite)
    first_image = Image.open(image_files[0])
    image_shape = [num_images, 512, 512]
    image_array = np.empty(image_shape)
    
    # Lade die Bilder in das NumPy-Array und konvertiere sie in Schwarz-Weiß-Bilder
    for i, image_file in enumerate(image_files):
        image = Image.open(image_file)
        new_image = image.convert('L')

        # Konvertiere das Bild zu einem Numpy Array und füge es zum Array hinzu
        image_array[i] = np.array(new_image)
    
    # Überprüfe, ob das NumPy-Array erfolgreich erstellt wurde
    if image_array is not None:
        print("Das NumPy-Array " + name + " wurde erfolgreich erstellt.")
        print("Form des Arrays:", image_array.shape)
    
    # Gib das NumPy-Array und die Klassennamen zurück
    return image_array, class_names


#______Laden und Vorverarbeiten des Datensatzes_________

train_ds, train_labels = load_images_to_array(train_folder, 'train')
val_ds, val_labels = load_images_to_array(val_folder, 'validation')

train_labels = np.array(train_labels)
train_labels = train_labels.astype(int)

val_labels = np.array(val_labels)
val_labels = val_labels.astype(int)

print(len(train_ds))
print(len(train_labels))
print(len(val_labels))

#_____Plot der Trainingsdaten_____

fig, ax = plt.subplots(1, 2)
ax[0].imshow(train_ds[70])
ax[1].imshow(val_ds[25])
plt.show()

#_________Modelldefinition__________

model = tf.keras.Sequential()
model.add(tf.keras.layers.Conv2D(16, (1, 1), activation='relu', input_shape=(512, 512, 1)))
model.add(tf.keras.layers.Conv2D(16, (3, 3), activation='relu', padding='same'))
model.add(tf.keras.layers.Conv2D(16, (3, 3), activation='relu', padding='same'))
model.add(tf.keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'))
model.add(tf.keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'))
model.add(tf.keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'))
model.add(tf.keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'))
model.add(tf.keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'))
model.add(tf.keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'))
model.add(tf.keras.layers.BatchNormalization())
model.add(tf.keras.layers.Conv2D(1, 3, activation='relu', padding='same'))
model.add(tf.keras.layers.Flatten())
model.add(tf.keras.layers.Dense(32, activation='relu'))
model.add(tf.keras.layers.Dense(num_classes, activation=None))

model.summary()

#________Kompilieren und Trainieren des Modells__________

model.compile(optimizer='adam',loss=tf.losses.SparseCategoricalCrossentroy(from_logits=True),metrics=['accuracy'])

history = model.fit(train_ds, train_labels, validation_data=(val_ds, val_labels), epochs=85)

# Modell speichern

model.save('Tafeln_Modell_neu_V22')

#______________Plot der Modell-History____________________

plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Modellgenauigkeit')
plt.xlabel('Epochen')
plt.ylabel('Genauigkeit')
plt.legend()
plt.show()

plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Modellverlust')
plt.xlabel('Epochen')
plt.ylabel('Verlust')
plt.legend()
plt.show()
